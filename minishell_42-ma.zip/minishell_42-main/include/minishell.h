/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:26:01 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 16:26:01 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include <errno.h>
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <sys/types.h>
# include <sys/stat.h>
# include <unistd.h>
# include <sys/wait.h>
# include <signal.h>
# include <readline/readline.h>
# include <readline/history.h>
# include "libft.h"

# define SUCCESS 0
# define ERROR 1

/* --- Redirection Types --- */
typedef enum e_redir_type
{
	RED_IN,
	RED_OUT,
	RED_APPEND,
	RED_HEREDOC
}	t_redir_type;

/* --- Token Types --- */
typedef enum e_token_type
{
	TOKEN_WORD,
	TOKEN_PIPE,
	TOKEN_REDIR_IN,
	TOKEN_REDIR_OUT,
	TOKEN_APPEND,
	TOKEN_HEREDOC
}	t_token_type;

/* --- Structures --- */
typedef struct s_redir
{
	char			*file;
	t_redir_type	type;
	struct s_redir	*next;
}	t_redir;

typedef struct s_cmd
{
	char			**args;
	t_redir			*redirs;
	int				fd_in;
	int				fd_out;
	struct s_cmd	*next;
}	t_cmd;

typedef struct s_env
{
	char			*key;
	char			*value;
	struct s_env	*next;
}	t_env;

typedef struct s_shell
{
	t_env			*env;
	int				last_status;
	int				stdin_bak;
	int				stdout_bak;
	t_cmd			*current_cmds;
}	t_shell;

typedef struct s_token
{
	char			*value;
	t_token_type	type;
	struct s_token	*next;
}	t_token;

/* ================= FUNCTION PROTOTYPES ================= */

/* --- Signals --- */
void	init_signals(void);
void	handle_sigint(int sig);

/* --- Lexer & Parser --- */
t_token	*tokenize(char *line);
t_token	*ft_new_token(char *value, t_token_type type);
void	ft_token_add_back(t_token **head, t_token *new);
void	free_tokens(t_token *head);
int		syntax_check(t_token *tokens);
t_cmd	*parse_tokens(t_token *tokens);

/* --- Expansions --- */
char	*get_env_value(char *var_name, t_shell *shell);
char	*expand_variables(char *input, t_shell *shell);

/* --- Executor & Redirections --- */
int		execute_commands(t_cmd *cmds, t_shell *shell);
void	execute_single_command(t_cmd *cmd, t_shell *shell);
void	execute_pipeline(t_cmd *cmd, t_shell *shell);
int		handle_redirections(t_cmd *cmd, t_shell *shell);
int		execute_heredoc(char *delimiter, t_shell *shell);
void	wait_all_children(pid_t last_pid, t_shell *shell);
char	*find_path(char *cmd, t_env *env_list);
char	*get_cmd_path(char *cmd, char **envp);

/* --- Built-ins --- */
int		is_builtin(char *cmd);
int		exec_builtin(t_cmd *cmd, t_shell *shell);
int		builtin_echo(char **args);
int		builtin_pwd(void);
int		builtin_env(t_shell *shell);
int		builtin_cd(char **args, t_shell *shell);
int		builtin_export(char **args, t_shell *shell);
int		builtin_unset(char **args, t_shell *shell);
int		builtin_exit(char **args, t_shell *shell);

/* --- Environment --- */
t_env	*env_init(char **envp);
t_env	*env_new(char *key, char *value);
void	env_add_back(t_env **env, t_env *new);
void	free_env(t_env *env);

/* --- Shell Lifecycle --- */
int		shell_init(t_shell *shell, char **envp);
void	shell_loop(t_shell *shell);
void	shell_cleanup(t_shell *shell);

/* --- Utils --- */
t_cmd	*cmd_new(void);
void	cmd_add_back(t_cmd **cmds, t_cmd *new);
t_redir	*redir_new(char *file, t_redir_type type);
void	redir_add_back(t_redir **redirs, t_redir *new);
void	free_cmds(t_cmd *cmds);
void	free_redirs(t_redir *redirs);
int		count_cmds(t_cmd *cmds);
int		ft_strcmp(const char *s1, const char *s2);
void	close_pipe(int *fd);
void	handle_pipe_dups(t_cmd *cmd, int prev_read_fd, int *fd);
void	free_array(char **arr);
void	add_arg(t_cmd *cmd, char *value);
void	add_redir(t_cmd *cmd, char *file, t_token_type type);

void	env_set(t_env **env, char *key, char *value);
void	env_unset(t_env **env, char *key);
char	*strip_quotes(char *input);
char	*append_char(char *str, char c);
char	*append_free(char *res, char *tmp);
void	handle_fork_sigint(int sig);
int		is_numeric(char *str);
int		is_valid_identifier(char *str);
void	check_directory_error(t_cmd *cmd, char *path, t_shell *shell);
void	free_and_exit(t_shell *shell, int status);

#endif