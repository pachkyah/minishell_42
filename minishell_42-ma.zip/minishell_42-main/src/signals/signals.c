/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signals.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pachkyah <pachkyah@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 15:59:20 by kseniia           #+#    #+#             */
/*   Updated: 2026/07/17 11:34:16 by pachkyah         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * @brief Handles the SIGINT signal in the interactive shell.
 *
 * Clears the current input line, displays a new prompt, and allows the
 * shell to continue accepting user input after Ctrl+C is pressed.
 *
 * @param sig The received signal number (unused).
 */
void	handle_sigint(int sig)
{
	(void)sig;
	write(1, "\n", 1);
	rl_on_new_line();
	rl_replace_line("", 0);
	rl_redisplay();
}

/**
 * @brief Handles the SIGINT signal in a forked process.
 *
 * Prints a newline when the process receives SIGINT. This handler is
 * intended for child processes where prompt redisplay is unnecessary.
 *
 * @param sig The received signal number (unused).
 */
void	handle_fork_sigint(int sig)
{
	(void)sig;
	write(1, "\n", 1);
}

/**
 * @brief Initializes the shell signal handlers.
 *
 * Configures the shell to handle SIGINT with a custom handler and
 * ignore SIGQUIT during interactive execution.
 */
void	init_signals(void)
{
	signal(SIGINT, handle_sigint);
	signal(SIGQUIT, SIG_IGN);
}
