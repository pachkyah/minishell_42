/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   envir_stuff.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pachkyah <pachkyah@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/21 18:58:28 by ypachkou          #+#    #+#             */
/*   Updated: 2026/07/17 11:33:04 by pachkyah         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * @brief Creates a new environment variable node.
 *
 * Allocates and initializes an environment list node by duplicating the
 * provided key and value strings.
 *
 * @param key Environment variable name.
 * @param value Environment variable value.
 * @return A pointer to the newly created node, or NULL on allocation failure.
 */
t_env	*env_new(char *key, char *value)
{
	t_env	*node;

	node = malloc(sizeof(t_env));
	if (!node)
		return (NULL);
	node->key = ft_strdup(key);
	node->value = ft_strdup(value);
	node->next = NULL;
	return (node);
}

/**
 * @brief Appends an environment node to the end of the list.
 *
 * If the list is empty, the new node becomes the head.
 *
 * @param env Pointer to the environment list.
 * @param new Node to append.
 */
void	env_add_back(t_env **env, t_env *new)
{
	t_env	*tmp;

	if (!*env)
	{
		*env = new;
		return ;
	}
	tmp = *env;
	while (tmp->next)
		tmp = tmp->next;
	tmp->next = new;
}

/**
 * @brief Initializes the environment list from the process environment.
 *
 * Parses the environment variable array and creates a linked list containing
 * each key-value pair.
 *
 * @param envp Array of environment variable strings.
 * @return Pointer to the initialized environment list, or NULL if empty.
 */
t_env	*env_init(char **envp)
{
	t_env	*env;
	char	*equal;
	char	*key;
	char	*value;
	int		i;

	env = NULL;
	i = 0;
	while (envp[i])
	{
		equal = ft_strchr(envp[i], '=');
		if (equal)
		{
			key = ft_substr(envp[i], 0, equal - envp[i]);
			value = ft_strdup(equal + 1);
			env_add_back(&env, env_new(key, value));
			free(key);
			free(value);
		}
		i++;
	}
	return (env);
}

/**
 * @brief Sets or creates an environment variable.
 *
 * Updates the value of an existing variable if the key is found.
 * Otherwise, appends a new variable to the environment list.
 *
 * @param env Pointer to the environment list.
 * @param key Environment variable name.
 * @param value New value to assign.
 */
void	env_set(t_env **env, char *key, char *value)
{
	t_env	*curr;

	curr = *env;
	while (curr)
	{
		if (ft_strcmp(curr->key, key) == 0)
		{
			free(curr->value);
			curr->value = ft_strdup(value);
			return ;
		}
		curr = curr->next;
	}
	env_add_back(env, env_new(key, value));
}

/**
 * @brief Removes an environment variable from the list.
 *
 * Searches for the variable with the specified key, unlinks it from the
 * list, and frees its associated memory.
 *
 * @param env Pointer to the environment list.
 * @param key Name of the variable to remove.
 */
void	env_unset(t_env **env, char *key)
{
	t_env	*curr;
	t_env	*prev;

	curr = *env;
	prev = NULL;
	while (curr)
	{
		if (ft_strcmp(curr->key, key) == 0)
		{
			if (prev == NULL)
				*env = curr->next;
			else
				prev->next = curr->next;
			free(curr->key);
			free(curr->value);
			free(curr);
			return ;
		}
		prev = curr;
		curr = curr->next;
	}
}
