/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pachkyah <pachkyah@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 15:52:19 by kseniia           #+#    #+#             */
/*   Updated: 2026/07/17 11:30:08 by pachkyah         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * @brief Entry point of the minishell program.
 *
 * Initializes the shell state, starts the interactive shell loop,
 * and performs cleanup before exiting.
 *
 * @param envp Array of environment variables used to initialize the shell.
 * @return 0 on normal termination, 1 if shell initialization fails.
 */
int	main(int argc, char **argv, char **envp)
{
	t_shell	shell;

	(void)argc;
	(void)argv;
	if (shell_init(&shell, envp) == ERROR)
		return (1);
	shell_loop(&shell);
	shell_cleanup(&shell);
	return (0);
}
