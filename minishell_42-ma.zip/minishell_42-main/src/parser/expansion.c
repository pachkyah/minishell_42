/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expansion.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:19:24 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 19:16:17 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	*get_env_value(char *var_name, t_shell *shell)
{
	t_env	*curr;

	if (ft_strncmp(var_name, "?", 2) == 0)
		return (ft_itoa(shell->last_status));
	curr = shell->env;
	while (curr != NULL)
	{
		if (ft_strcmp(curr->key, var_name) == 0)
		{
			if (curr->value)
				return (ft_strdup(curr->value));
			return (ft_strdup(""));
		}
		curr = curr->next;
	}
	return (ft_strdup(""));
}

static char	*handle_dollar(char *input, int *i, t_shell *shell)
{
	int		start;
	char	*var_name;
	char	*var_val;

	(*i)++;
	if (input[*i] == '?')
	{
		(*i)++;
		return (ft_itoa(shell->last_status));
	}
	start = *i;
	while (input[*i] && (ft_isalnum(input[*i]) || input[*i] == '_'))
		(*i)++;
	if (start == *i)
		return (ft_strdup("$"));
	var_name = ft_substr(input, start, *i - start);
	var_val = get_env_value(var_name, shell);
	free(var_name);
	return (var_val);
}

static char	*handle_expansion_char(char *input, int *i, t_shell *shell,
		char *state)
{
	if (input[*i] == '\'' && !state[1])
	{
		state[0] = !state[0];
		return (append_char(ft_strdup(""), input[(*i)++]));
	}
	else if (input[*i] == '\"' && !state[0])
	{
		state[1] = !state[1];
		return (append_char(ft_strdup(""), input[(*i)++]));
	}
	else if (input[*i] == '$' && !state[0])
	{
		return (handle_dollar(input, i, shell));
	}
	return (append_char(ft_strdup(""), input[(*i)++]));
}

char	*expand_variables(char *input, t_shell *shell)
{
	int		i;
	char	state[2];
	char	*res;
	char	*tmp;

	i = 0;
	state[0] = 0;
	state[1] = 0;
	res = ft_strdup("");
	while (input[i])
	{
		tmp = handle_expansion_char(input, &i, shell, state);
		res = append_free(res, tmp);
	}
	return (res);
}
