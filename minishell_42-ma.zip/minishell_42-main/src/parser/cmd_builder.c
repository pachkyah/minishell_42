/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cmd_builder.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:11:48 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 16:13:04 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	handle_token_type(t_token *t, t_cmd *curr_cmd)
{
	if (t->type >= TOKEN_REDIR_IN && t->type <= TOKEN_HEREDOC)
	{
		if (t->next)
			add_redir(curr_cmd, t->next->value, t->type);
	}
	else if (t->type == TOKEN_WORD)
		add_arg(curr_cmd, t->value);
}

t_cmd	*parse_tokens(t_token *tokens)
{
	t_cmd	*head;
	t_cmd	*curr_cmd;
	t_token	*t;

	head = cmd_new();
	if (!head)
		return (NULL);
	curr_cmd = head;
	t = tokens;
	while (t)
	{
		if (t->type == TOKEN_PIPE)
		{
			cmd_add_back(&head, cmd_new());
			curr_cmd = curr_cmd->next;
		}
		else
			handle_token_type(t, curr_cmd);
		if (t->type >= TOKEN_REDIR_IN && t->type <= TOKEN_HEREDOC && t->next)
			t = t->next;
		t = t->next;
	}
	return (head);
}
