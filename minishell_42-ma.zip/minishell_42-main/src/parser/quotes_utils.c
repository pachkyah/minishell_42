/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   quotes_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:15:04 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 19:50:13 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static int	should_keep_char(char c, char *s_q, char *d_q)
{
	if (c == '\'' && !(*d_q))
	{
		*s_q = !(*s_q);
		return (0);
	}
	else if (c == '\"' && !(*s_q))
	{
		*d_q = !(*d_q);
		return (0);
	}
	return (1);
}

char	*strip_quotes(char *input)
{
	int		i;
	char	s_q;
	char	d_q;
	char	*res;

	if (!input)
		return (NULL);
	i = 0;
	s_q = 0;
	d_q = 0;
	res = ft_strdup("");
	while (input[i])
	{
		if (should_keep_char(input[i], &s_q, &d_q))
			res = append_char(res, input[i]);
		i++;
	}
	return (res);
}

char	*append_free(char *res, char *tmp)
{
	char	*new_res;

	new_res = ft_strjoin(res, tmp);
	free(res);
	free(tmp);
	return (new_res);
}

char	*append_char(char *str, char c)
{
	char	tmp[2];
	char	*res;

	tmp[0] = c;
	tmp[1] = '\0';
	res = ft_strjoin(str, tmp);
	free(str);
	return (res);
}
