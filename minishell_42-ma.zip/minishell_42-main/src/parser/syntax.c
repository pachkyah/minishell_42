/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   syntax.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pachkyah <pachkyah@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:14:12 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/17 11:39:00 by pachkyah         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * @brief Validates the syntax of a pipe token.
 *
 * Ensures that a pipe is followed by a valid command rather than another
 * pipe or the end of the token list. Prints an error message if the
 * syntax is invalid.
 *
 * @param curr Pointer to the current pipe token.
 * @return 1 if the pipe syntax is valid, 0 otherwise.
 */
static int	check_pipe(t_token *curr)
{
	if (!curr->next || curr->next->type == TOKEN_PIPE)
	{
		ft_putstr_fd("minishell: syntax error near ", 2);
		ft_putstr_fd("unexpected token `|'\n", 2);
		return (0);
	}
	return (1);
}

/**
 * @brief Validates the syntax of a redirection token.
 *
 * Ensures that a redirection operator is followed by a filename token.
 * Prints an error message if the syntax is invalid.
 *
 * @param curr Pointer to the current redirection token.
 * @return 1 if the redirection syntax is valid, 0 otherwise.
 */
static int	check_redir(t_token *curr)
{
	if (!curr->next || curr->next->type != TOKEN_WORD)
	{
		ft_putstr_fd("minishell: syntax error near ", 2);
		ft_putstr_fd("unexpected token `newline'\n", 2);
		return (0);
	}
	return (1);
}


/**
 * @brief Checks the syntax of a token list.
 *
 * Validates the placement of pipes and redirection operators, reporting
 * syntax errors when invalid token sequences are encountered.
 *
 * @param tokens Head of the token list to validate.
 * @return 1 if the token sequence is syntactically valid, 0 otherwise.
 */
int	syntax_check(t_token *tokens)
{
	t_token	*curr;

	curr = tokens;
	if (curr && curr->type == TOKEN_PIPE)
	{
		ft_putstr_fd("minishell: syntax error near ", 2);
		ft_putstr_fd("unexpected token `|'\n", 2);
		return (0);
	}
	while (curr)
	{
		if (curr->type == TOKEN_PIPE)
		{
			if (!check_pipe(curr))
				return (0);
		}
		else if (curr->type == TOKEN_REDIR_IN || curr->type == TOKEN_REDIR_OUT
			|| curr->type == TOKEN_APPEND || curr->type == TOKEN_HEREDOC)
		{
			if (!check_redir(curr))
				return (0);
		}
		curr = curr->next;
	}
	return (1);
}
