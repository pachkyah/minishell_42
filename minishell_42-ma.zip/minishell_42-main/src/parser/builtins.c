/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtins.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 19:00:35 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 19:26:11 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	builtin_echo(char **args)
{
	int	i;
	int	newline;

	i = 1;
	newline = 1;
	while (args[i] && ft_strncmp(args[i], "-n", 3) == 0)
	{
		newline = 0;
		i++;
	}
	while (args[i])
	{
		ft_putstr_fd(args[i], 1);
		if (args[i + 1])
			ft_putstr_fd(" ", 1);
		i++;
	}
	if (newline)
		ft_putstr_fd("\n", 1);
	return (0);
}

int	builtin_pwd(void)
{
	char	cwd[1024];

	if (getcwd(cwd, sizeof(cwd)) != NULL)
	{
		ft_putstr_fd(cwd, 1);
		ft_putstr_fd("\n", 1);
		return (0);
	}
	perror("minishell: pwd");
	return (1);
}

int	builtin_env(t_shell *shell)
{
	t_env	*curr;

	curr = shell->env;
	while (curr)
	{
		if (curr->value)
		{
			ft_putstr_fd(curr->key, 1);
			ft_putstr_fd("=", 1);
			ft_putstr_fd(curr->value, 1);
			ft_putstr_fd("\n", 1);
		}
		curr = curr->next;
	}
	return (0);
}

static void	update_pwd_env(t_shell *shell, char *old_cwd)
{
	char	cwd[1024];

	if (old_cwd[0] != '\0')
		env_set(&shell->env, "OLDPWD", old_cwd);
	else
		env_set(&shell->env, "OLDPWD", "");
	if (getcwd(cwd, sizeof(cwd)) != NULL)
		env_set(&shell->env, "PWD", cwd);
}

int	builtin_cd(char **args, t_shell *shell)
{
	char	cwd[1024];
	char	*target;

	if (!args[1])
	{
		ft_putstr_fd("minishell: cd: relative or absolute path required\n", 2);
		return (1);
	}
	if (args[2])
	{
		ft_putstr_fd("minishell: cd: too many arguments\n", 2);
		return (2);
	}
	target = args[1];
	if (getcwd(cwd, sizeof(cwd)) == NULL)
		cwd[0] = '\0';
	if (chdir(target) != 0)
	{
		perror("minishell: cd");
		return (1);
	}
	update_pwd_env(shell, cwd);
	return (0);
}
