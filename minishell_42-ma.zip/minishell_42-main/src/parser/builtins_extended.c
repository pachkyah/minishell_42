/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtins_extended.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 17:01:57 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 19:31:07 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	clean_exit_and_exit(t_shell *shell, char **args, int code)
{
	free_env(shell->env);
	rl_clear_history();
	if (shell->current_cmds)
	{
		free_cmds(shell->current_cmds);
		shell->current_cmds = NULL;
	}
	else if (args)
	{
		free_array(args);
	}
	exit(code);
}

int	builtin_exit(char **args, t_shell *shell)
{
	int	exit_code;

	ft_putstr_fd("exit\n", 1);
	exit_code = shell->last_status;
	if (args && args[0] && args[1])
	{
		if (!is_numeric(args[1]))
		{
			ft_putstr_fd("minishell: exit: ", 2);
			ft_putstr_fd(args[1], 2);
			ft_putstr_fd(": numeric argument required\n", 2);
			clean_exit_and_exit(shell, args, 2);
		}
		if (args[2])
		{
			ft_putstr_fd("minishell: exit: too many arguments\n", 2);
			return (2);
		}
		exit_code = ft_atoi(args[1]);
	}
	clean_exit_and_exit(shell, args, exit_code);
	return (0);
}

int	is_valid_identifier(char *str)
{
	int	i;

	if (!str || (!ft_isalpha(str[0]) && str[0] != '_'))
		return (0);
	i = 1;
	while (str[i])
	{
		if (!ft_isalnum(str[i]) && str[i] != '_')
			return (0);
		i++;
	}
	return (1);
}

static int	process_export_arg(char *arg, t_shell *shell)
{
	char	*equal;
	char	*key;
	char	*value;

	equal = ft_strchr(arg, '=');
	if (equal)
		key = ft_substr(arg, 0, equal - arg);
	else
		key = ft_strdup(arg);
	if (!is_valid_identifier(key))
	{
		ft_putstr_fd("minishell: export: `", 2);
		ft_putstr_fd(arg, 2);
		ft_putstr_fd("': not a valid identifier\n", 2);
		free(key);
		return (1);
	}
	if (equal)
	{
		value = ft_strdup(equal + 1);
		env_set(&shell->env, key, value);
		free(value);
	}
	free(key);
	return (0);
}

int	builtin_export(char **args, t_shell *shell)
{
	int	i;
	int	status;

	i = 1;
	status = 0;
	if (!args[i])
		return (builtin_env(shell));
	while (args[i])
	{
		if (process_export_arg(args[i], shell))
			status = 1;
		i++;
	}
	return (status);
}
