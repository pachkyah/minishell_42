/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirection.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:24:21 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 16:24:21 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static int	open_redir_file(t_redir *tmp, t_shell *shell)
{
	int	fd;

	fd = -1;
	if (tmp->type == RED_IN)
		fd = open(tmp->file, O_RDONLY);
	else if (tmp->type == RED_OUT)
		fd = open(tmp->file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
	else if (tmp->type == RED_APPEND)
		fd = open(tmp->file, O_WRONLY | O_CREAT | O_APPEND, 0644);
	else if (tmp->type == RED_HEREDOC)
		fd = execute_heredoc(tmp->file, shell);
	return (fd);
}

int	handle_redirections(t_cmd *cmd, t_shell *shell)
{
	t_redir	*tmp;
	int		fd;

	tmp = cmd->redirs;
	while (tmp)
	{
		fd = open_redir_file(tmp, shell);
		if (fd < 0)
		{
			perror(tmp->file);
			return (-1);
		}
		if (tmp->type == RED_IN || tmp->type == RED_HEREDOC)
			dup2(fd, STDIN_FILENO);
		else
			dup2(fd, STDOUT_FILENO);
		close(fd);
		tmp = tmp->next;
	}
	return (0);
}

void	wait_all_children(pid_t last_pid, t_shell *shell)
{
	int		status;
	pid_t	pid;

	waitpid(last_pid, &status, 0);
	if (WIFEXITED(status))
		shell->last_status = WEXITSTATUS(status);
	else if (WIFSIGNALED(status))
		shell->last_status = 128 + WTERMSIG(status);
	pid = waitpid(-1, NULL, 0);
	while (pid > 0)
		pid = waitpid(-1, NULL, 0);
}

static void	child_process(t_cmd *cmd, t_shell *shell, int prev_fd, int *pipefd)
{
	if (prev_fd != 0)
	{
		dup2(prev_fd, STDIN_FILENO);
		close(prev_fd);
	}
	if (cmd->next)
	{
		close(pipefd[0]);
		dup2(pipefd[1], STDOUT_FILENO);
		close(pipefd[1]);
	}
	if (handle_redirections(cmd, shell) < 0)
	{
		free_env(shell->env);
		exit(1);
	}
	execute_single_command(cmd, shell);
	free_env(shell->env);
	exit(127);
}

void	execute_pipeline(t_cmd *cmd, t_shell *shell)
{
	int		pipefd[2];
	int		prev_fd;
	pid_t	pid;

	pid = -1;
	prev_fd = 0;
	while (cmd)
	{
		if (cmd->next)
			pipe(pipefd);
		pid = fork();
		if (pid == 0)
			child_process(cmd, shell, prev_fd, pipefd);
		if (prev_fd != 0)
			close(prev_fd);
		if (cmd->next)
		{
			close(pipefd[1]);
			prev_fd = pipefd[0];
		}
		cmd = cmd->next;
	}
	if (pid != -1)
		wait_all_children(pid, shell);
}
