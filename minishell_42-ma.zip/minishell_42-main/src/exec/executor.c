/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   executor.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kamelina <kamelina@student.42prague.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 19:11:11 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/15 19:11:11 by kamelina         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	execute_heredoc(char *delimiter, t_shell *shell)
{
	int		fd[2];
	char	*line;

	(void)shell;
	if (pipe(fd) == -1)
		return (-1);
	while (1)
	{
		line = readline("> ");
		if (!line || ft_strcmp(line, delimiter) == 0)
		{
			free(line);
			break ;
		}
		ft_putendl_fd(line, fd[1]);
		free(line);
	}
	close(fd[1]);
	return (fd[0]);
}

static int	restore_fds(t_shell *shell, int status)
{
	dup2(shell->stdin_bak, STDIN_FILENO);
	dup2(shell->stdout_bak, STDOUT_FILENO);
	close(shell->stdin_bak);
	close(shell->stdout_bak);
	return (status);
}

int	execute_commands(t_cmd *cmds, t_shell *shell)
{
	if (!cmds || !cmds->args || !cmds->args[0] || !cmds->args[0][0])
		return (0);
	if (cmds && !cmds->next && is_builtin(cmds->args[0]))
	{
		shell->stdin_bak = dup(STDIN_FILENO);
		shell->stdout_bak = dup(STDOUT_FILENO);
		if (handle_redirections(cmds, shell) < 0)
			return (restore_fds(shell, 1));
		shell->last_status = exec_builtin(cmds, shell);
		return (restore_fds(shell, shell->last_status));
	}
	signal(SIGINT, handle_fork_sigint);
	execute_pipeline(cmds, shell);
	init_signals();
	return (shell->last_status);
}

static void	handle_exec_error(char *cmd, char *path, t_shell *shell)
{
	ft_putstr_fd("minishell: ", 2);
	ft_putstr_fd(cmd, 2);
	ft_putstr_fd(": ", 2);
	ft_putstr_fd(strerror(errno), 2);
	ft_putstr_fd("\n", 2);
	free(path);
	free_env(shell->env);
	if (shell->current_cmds)
		free_cmds(shell->current_cmds);
	if (errno == EACCES)
		exit(126);
	exit(127);
}

void	execute_single_command(t_cmd *cmd, t_shell *shell)
{
	char	*path;

	if (!cmd->args || !cmd->args[0] || !cmd->args[0][0])
		free_and_exit(shell, 0);
	if (is_builtin(cmd->args[0]))
	{
		shell->last_status = exec_builtin(cmd, shell);
		free_and_exit(shell, shell->last_status);
	}
	path = find_path(cmd->args[0], shell->env);
	check_directory_error(cmd, path, shell);
	if (!path)
	{
		ft_putstr_fd("minishell: ", 2);
		ft_putstr_fd(cmd->args[0], 2);
		ft_putstr_fd(": command not found\n", 2);
		free_and_exit(shell, 127);
	}
	if (execve(path, cmd->args, NULL) == -1)
		handle_exec_error(cmd->args[0], path, shell);
}
