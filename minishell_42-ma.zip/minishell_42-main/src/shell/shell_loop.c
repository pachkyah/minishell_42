/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shell_loop.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pachkyah <pachkyah@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:05:36 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/17 11:36:26 by pachkyah         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * @brief Expands variables and removes quotes in a command.
 *
 * Expands environment variables in the command arguments and redirection
 * filenames, then removes any remaining quote characters.
 *
 * @param cmd Command whose arguments and redirections are processed.
 * @param shell Pointer to the shell state used for variable expansion.
 */
static void	expand_cmd_args(t_cmd *cmd, t_shell *shell)
{
	int		i;
	char	*expanded;
	t_redir	*redir;

	i = 0;
	while (cmd->args && cmd->args[i])
	{
		expanded = expand_variables(cmd->args[i], shell);
		free(cmd->args[i]);
		cmd->args[i] = strip_quotes(expanded);
		free(expanded);
		i++;
	}
	redir = cmd->redirs;
	while (redir)
	{
		if (redir->file)
		{
			expanded = expand_variables(redir->file, shell);
			free(redir->file);
			redir->file = strip_quotes(expanded);
			free(expanded);
		}
		redir = redir->next;
	}
}

/**
 * @brief Parses an input line into a command list.
 *
 * Tokenizes the input, validates its syntax, and converts the resulting
 * tokens into a linked list of commands.
 *
 * @param line Input command line.
 * @return A linked list of parsed commands, or NULL if parsing fails.
 */
static t_cmd	*parse_line_to_cmds(char *line)
{
	t_token	*tokens;
	t_cmd	*cmds;

	tokens = tokenize(line);
	if (!tokens)
		return (NULL);
	if (!syntax_check(tokens))
	{
		free_tokens(tokens);
		return (NULL);
	}
	cmds = parse_tokens(tokens);
	free_tokens(tokens);
	return (cmds);
}

/**
 * @brief Removes an empty command name from the argument list.
 *
 * If variable expansion produces an empty first argument while additional
 * arguments remain, shifts the remaining arguments to preserve a valid
 * command layout.
 *
 * @param curr_cmd Command to update.
 */
static void	handle_empty_arg(t_cmd *curr_cmd)
{
	int	i;

	if (curr_cmd->args && curr_cmd->args[0]
		&& curr_cmd->args[0][0] == '\0' && curr_cmd->args[1])
	{
		i = 0;
		free(curr_cmd->args[0]);
		while (curr_cmd->args[i])
		{
			curr_cmd->args[i] = curr_cmd->args[i + 1];
			i++;
		}
	}
}

/**
 * @brief Processes and executes a command line.
 *
 * Parses the input line, expands variables, removes quotes, executes the
 * resulting commands, and releases all allocated resources.
 *
 * @param line Input command line.
 * @param shell Pointer to the shell state.
 */
void	process_line(char *line, t_shell *shell)
{
	t_cmd	*cmds;
	t_cmd	*curr_cmd;

	if (!line || !*line)
		return ;
	add_history(line);
	cmds = parse_line_to_cmds(line);
	if (!cmds)
		return ;
	curr_cmd = cmds;
	while (curr_cmd)
	{
		expand_cmd_args(curr_cmd, shell);
		handle_empty_arg(curr_cmd);
		curr_cmd = curr_cmd->next;
	}
	shell->current_cmds = cmds;
	shell->last_status = execute_commands(cmds, shell);
	free_cmds(cmds);
	shell->current_cmds = NULL;
}

/**
 * @brief Runs the interactive shell loop.
 *
 * Repeatedly reads user input, processes each command line, and exits when
 * an end-of-file condition is encountered.
 *
 * @param shell Pointer to the shell state.
 */
void	shell_loop(t_shell *shell)
{
	char	*line;

	while (1)
	{
		line = readline("minishell> ");
		if (!line)
			break ;
		process_line(line, shell);
		free(line);
	}
}
