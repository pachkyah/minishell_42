/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   shell_init.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pachkyah <pachkyah@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/07/15 16:04:30 by kamelina          #+#    #+#             */
/*   Updated: 2026/07/17 11:30:41 by pachkyah         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

/**
 * @brief Initializes the shell state.
 *
 * Creates the shell environment from the provided environment variables,
 * initializes the shell exit status, and sets up signal handlers.
 *
 * @param shell Pointer to the shell structure to initialize.
 * @param envp Array of environment variables.
 * @return SUCCESS on successful initialization, ERROR otherwise.
 */
int	shell_init(t_shell *shell, char **envp)
{
	if (!shell)
		return (ERROR);
	shell->env = env_init(envp);
	if (!shell->env)
		return (ERROR);
	shell->last_status = 0;
	init_signals();
	return (SUCCESS);
}
